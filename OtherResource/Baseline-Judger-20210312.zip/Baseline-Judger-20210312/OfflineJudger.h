//
// Created by QAQ on 2021/3/12.
//

#ifndef HWCODECRAFT2021_OFFLINEJUDGER_H
#define HWCODECRAFT2021_OFFLINEJUDGER_H

#include "GlobalDefinition.h"

void runJudger(std::string inputFile,std::string outputFile);

#endif //HWCODECRAFT2021_OFFLINEJUDGER_H
